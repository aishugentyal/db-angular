import { Component, Input, OnInit } from '@angular/core';
import { HeroService } from './herodata.service';

@Component({
  selector: 'app-grid',
  template: `
  <h2>Version : {{ compVersion }} </h2>
   <table class="table table-striped table-bordered table-responsive table-sm">
    <thead  class="table-dark">
      <tr>
        <th>Sl #</th>
        <th>Title</th>
        <th>Full Name</th>
        <th>Poster</th>
        <th>City</th>
        <th>Release Date</th>
        <th>Ticket Price</th>
        <th>Movies Count</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of data">
          <td>{{ hero.sl }}</td>
          <td>{{ hero.title | uppercase }}</td>
          <td>{{ hero.firstname+" "+hero.lastname }}</td>
          <td>
            <img width="50" [src]="hero.poster" [alt]="hero.title">
          </td>
          <td>{{ hero.city }}</td>
          <td>{{ hero.releasedate | date : 'dd-MMM-yyyy' }}</td>
          <td>{{ hero.ticketprice | currency :'INR':'symbol':'3.2-3' }}</td>
          <td>
            <button class="btn btnBox">Total Movies : {{ hero.movieslist.length }}</button>
          </td>
        </tr>
    </tbody>
  </table>
  `,
  styles: [
  ]
})
export class GridComponent {
  compVersion = 0;
  @Input('compdata') data:any = [];
  
  constructor(private hs:HeroService){
    this.compVersion = this.hs.getVersion();
    this.data = this.hs.getdata();
  }
}
