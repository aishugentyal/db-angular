import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <div class="container">
    <h1> DB Heroes </h1>
    <app-header></app-header>
    <hr>
    <app-grid></app-grid>
   </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step7-assignment';
  
}
