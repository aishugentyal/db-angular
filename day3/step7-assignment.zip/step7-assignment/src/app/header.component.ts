import { Component, Input } from '@angular/core';
import { HeroService } from './herodata.service';

@Component({
  selector: 'app-header',
  template: `
  <h2>Version : {{ compVersion }} </h2>
    <ul class="nav justify-content-center">
        <li class="nav-item" *ngFor="let hero of data">
            <a class="nav-link" href="">{{ hero.title }}</a>
        </li>
    </ul>
  `,
  styles: [
  ]
})
export class HeaderComponent{
  compVersion = 0;
  @Input('compdata') data:any = [];
  constructor(private hs:HeroService){
    this.compVersion = this.hs.getVersion();
    this.data = hs.getdata();
  }
}
