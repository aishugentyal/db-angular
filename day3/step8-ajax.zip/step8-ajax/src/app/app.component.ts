import { Component } from '@angular/core';
import { UserServices } from './user.services';

@Component({
  selector: 'app-root',
  template: `
   <h1>Consuming External API</h1>
   <hr>
   <table class="table table-striped table-bordered table-responsive table-sm">
    <thead  class="table-dark">
      <tr>
        <th>ID #</th>
        <th>Name</th>
        <th>User Name</th>
        <th>eMail</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let user of jsondata">
          <td>{{ user.id }}</td>
          <td>{{ user.name }}</td>
          <td>{{ user.username }}</td>
          <td>{{ user.email }}</td>
        </tr>
    </tbody>
  </table>
  `,
  styles: []
})
export class AppComponent {
  title = 'step8-ajax';
  jsondata:any = [];

  constructor(private us:UserServices){}

  ngOnInit(){
    this.us.getUserData().subscribe(res => this.jsondata = res);
  }
}
