import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class UserServices{
    /*     
    serviceData:any = [];
    constructor(private http:HttpClient){}
    getUserData(){
        this.http.get("https://jsonplaceholder.typicode.com/users").subscribe(res=>this.serviceData = res);
    } 
    */
    serviceData:any = [];
    constructor(private http:HttpClient){}
    getUserData(){
        return this.http.get("https://jsonplaceholder.typicode.com/users");
    }
}