import { Component } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <div>
      <h2>Child Component</h2>
      <ng-content select="p"></ng-content>
      <fieldset>
        <legend>My List</legend>
        <ng-content select="ul"></ng-content>
      </fieldset>
      <ng-content></ng-content>
    </div>
  `,
  styles: [
  ]
})
export class ChildComponent{


}
