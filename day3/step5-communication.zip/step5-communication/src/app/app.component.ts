import { Component, ViewChild } from '@angular/core';
import { ThreeComponent } from './three.component';

@Component({
  selector: 'app-root',
  template: `
   <div *ngIf="show">
   <div style="width: 200px; margin : auto">
    <img #img height="200" src="assets/images/default.jpg">
    <hr>
    <button #btn1 data-title="superman" (click)="changePhoto(img, btn1)">Load Superman's Photo </button>
    <br>
    <button #btn2 data-title="batman" (click)="changePhoto(img, btn2)">Load Batman's Photo </button>
    <br>
    <button #btn3 data-title="ironman" (click)="changePhoto(img, btn3)">Load Ironman's Photo </button>
    </div>
    <hr>
   </div>
    <div *ngIf="show">
    <app-child>
      <ul>
        <li>List Item 1</li>
        <li>List Item 2</li>
        <li>List Item 3</li>
        <li>List Item 4</li>
        <li>List Item 5</li>
      </ul>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptas eum ab blanditiis perspiciatis incidunt officiis accusamus exercitationem, pariatur dolorem, repudiandae deserunt! Magni, ullam aperiam? Exercitationem rem cumque aliquam ex qui.
      </p>
      <button>Click Button</button>
    </app-child>
    <app-child>
      <ul>
        <li>List Item 1</li>
        <li>List Item 2</li>
        <li>List Item 3</li>
        <li>List Item 4</li>
        <li>List Item 5</li>
      </ul>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptas eum ab blanditiis perspiciatis incidunt officiis accusamus exercitationem, pariatur dolorem, repudiandae deserunt! Magni, ullam aperiam? Exercitationem rem cumque aliquam ex qui.
      </p>
    </app-child>
    <app-child>
      <button>Click Button</button>
      <ul>
        <li>List Item 1</li>
        <li>List Item 2</li>
        <li>List Item 3</li>
        <li>List Item 4</li>
        <li>List Item 5</li>
      </ul>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptas eum ab blanditiis perspiciatis incidunt officiis accusamus exercitationem, pariatur dolorem, repudiandae deserunt! Magni, ullam aperiam? Exercitationem rem cumque aliquam ex qui.
      </p>
    </app-child>
    </div>
    <div *ngIf="show">
      <h2>{{ title }}</h2>
      <input type="range" #pow (input)="appsec.title = pow.value+''">
      <app-second (secondEvent)="secondEventHandler($event)" #appsec data="hello there"></app-second>
    </div>
   <!--  
    <app-three #three></app-three>
    <button (click)="three.increasePower()">Increase Power</button>
    <button (click)="three.decreasePower()">Decrease Power</button> 
    -->
    <app-three></app-three>
    <button (click)="appIncreasePower()">Increase Power</button>
    <button (click)="appDecreasePower()">Decrease Power</button> 
  `,
  styles: []
})
export class AppComponent {
  title = 'step5-communication';
  show = false;

  @ViewChild(ThreeComponent) threeComp:any;

  changePhoto(tag:any, srcTag:any){
    // alert( srcTag.getAttribute("data-title") );
    let path = "assets/images/"+srcTag.getAttribute("data-title")+".jpg";
    tag.src = path;
  }

  secondEventHandler(msg:any){
    // alert(msg);
    this.title = msg;
  }

  appIncreasePower(){
    this.threeComp.increasePower();
  }
  appDecreasePower(){
    this.threeComp.decreasePower();
  }
}
