import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-second',
  template: `
    <div>
      <h1>Component with Attributes</h1>
      <h2>Title now is : {{ title }}</h2>
      <input #ti type="text">
      <button (click)="dispatchSecondEvent(ti.value)">Change Title</button>
    </div>
  `,
  styles: [
  ]
})
export class SecondComponent {
  @Input('data') title = "default value";
  @Output() secondEvent:EventEmitter<any> = new EventEmitter();

  dispatchSecondEvent(msg:any){
    // alert(msg);
    this.secondEvent.emit(msg)
  }
}
