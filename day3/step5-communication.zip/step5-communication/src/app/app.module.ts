import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ChildComponent } from './child.component';
import { SecondComponent } from './second.component';
import { ThreeComponent } from './three.component';

@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    SecondComponent,
    ThreeComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
