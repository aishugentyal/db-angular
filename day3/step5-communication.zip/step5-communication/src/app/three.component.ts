import { Component} from '@angular/core';

@Component({
  selector: 'app-three',
  template: `
   <div>
    <h4>Third Component</h4>
    <h3>Power is {{ power }}</h3>
   </div>
  `,
  styles: []
})
export class ThreeComponent{
  power = 0;
  increasePower(){
    this.power = this.power+1;
  }
  decreasePower(){
    this.power = this.power-1;
  }
}
