import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
   <div>
    <h1>Child Component</h1>
    <h2>Power is : {{ power }}</h2>
   </div>
  `,
  styles: [
  ]
})
export class ChildComponent implements OnInit, OnChanges, OnDestroy{
  @Input() power = 0;

  constructor(){
    console.log("ChildComponent's constructor was called")
  }

  ngOnInit(){
    console.log("ChildComponent's ngOnInit was called")
  };
  
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ChildComponent's ngOnChanges was called");
    // console.log(changes['power'].currentValue);
    if(changes['power'].currentValue > 50){
      this.power = 50
    }else{
      this.power = changes['power'].currentValue
    }
  };
  
  ngOnDestroy(): void {
    console.log("ChildComponent's ngOnDestroy was called")
  }
}
