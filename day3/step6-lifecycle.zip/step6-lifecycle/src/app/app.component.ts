import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <input type="range" (input)="changePower($event)">{{ appPower }}
    <app-child *ngIf="appPower < 70" [power]="appPower"></app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step6-lifecycle';
  appPower = 1;
  changePower(evt:any){
    this.appPower = Number(evt.target.value);
  }
}
