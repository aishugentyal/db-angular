import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : "gen"
})
export class GenPipe implements PipeTransform{
    transform(...args:any){
       if( args[1] === "male"){
           return "Mr "+args[0];
        }else{
           return "Miss "+args[0];
       }
    }
}
