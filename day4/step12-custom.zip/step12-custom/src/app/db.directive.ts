import { Directive, ElementRef, Input } from "@angular/core";
/*
ng-content    tag selector
router-outlet tag selector

[ngStyle]     attribute selector

.player        class selector
*/

@Directive({
   selector : "[db]"
})
export class DBDirective{
    @Input() db:any;
    constructor(private domElement:ElementRef){}
    ngOnInit(){
        console.log(this.db);
        let content = this.domElement.nativeElement.textContent;
        this.domElement.nativeElement.outerHTML = "<"+this.db+">"+content+"</"+this.db+">";
    }
}