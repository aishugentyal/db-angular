import { Pipe } from "@angular/core";

@Pipe({
    name : "dbrev"
})
export class RevPipe{
    transform(...args:any){
        return args[0].split("").reverse().join("");
    }
};

