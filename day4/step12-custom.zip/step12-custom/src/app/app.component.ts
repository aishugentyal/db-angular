import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Custom</h1>
    <app-db></app-db>
  `,
  styles: []
})
export class AppComponent {
  title = 'step12-custom';
}
