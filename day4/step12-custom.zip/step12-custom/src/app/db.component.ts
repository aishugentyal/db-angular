import { Component } from "@angular/core";

@Component({
    selector : "app-db",
    template : `
        <h1>Hello from {{ title | dbrev }}</h1>
        <h2>Hello there</h2>
        <h3 db="button">I am about to be changed</h3>
        <p db="button">a Paragraph button</p>
        <p db="h1">a h1 tag</p>

    `
})
export class DBComp{
    title = "tnenopmoC BD"
}