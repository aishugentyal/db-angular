import { NgModule } from "@angular/core";
import { DBDirective } from "./db.directive";
import { RevPipe } from "./rev.pipe";

@NgModule({
    declarations : [RevPipe, DBDirective],
    exports : [RevPipe, DBDirective]
})
export class DBModule{

}