import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { DBComp } from './db.component';
import { DBModule } from './db.module';

@NgModule({
  declarations: [ AppComponent, DBComp],
  imports: [ BrowserModule, DBModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
