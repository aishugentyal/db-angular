import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-template-form',
  template: `
             <h2>Template driven forms</h2>
             <form #myform="ngForm" action="#" method="get" (submit)="submitHandler(myform, $event)">
               <div class="mb-3">
                <label for="userName" class="form-label">User Name : </label>
                <input required #uname="ngModel" [(ngModel)]="user.name" name="userName" class="form-control" id="userName">
                <div *ngIf="uname.touched && uname.invalid" class="form-text text-danger">User Name is Required</div>
              </div>
              <div class="mb-3">
                <label for="userAge" class="form-label">User Age : </label>
                <input required #uage="ngModel" [(ngModel)]="user.age" name="userAge" type="number" class="form-control" id="userAge">
                <div *ngIf="uage.touched && uage.invalid" class="form-text text-danger">User Age is Required</div>
              </div>
              <div class="mb-3">
                <label for="userPhone" class="form-label">User Phone : </label>
                <input required #uphone="ngModel" [(ngModel)]="user.phone" name="userPhone" type="tel" class="form-control" id="userPhone">
                <div *ngIf="uphone.touched && uphone.invalid" class="form-text text-danger">User Phone is Required</div>
              </div>
              <button type="submit" class="btn btn-primary">Register</button>
             </form>
             <ul>
              <li> User Name : {{ user.name }}</li>
              <li> User Age : {{ user.age }}</li>
              <li> User Phone : {{ user.phone }}</li>
             </ul>
             <div class="row">
              <div class="col-4">
                <ul>
                  <li *ngIf="uname.untouched">User Name is Untouched</li>
                  <li *ngIf="uname.touched">User Name is Touched</li>
                  <li *ngIf="uname.dirty">User Name is Dirty</li>
                  <li *ngIf="uname.pristine">User Name is Pristine</li>
                  <li *ngIf="uname.valid">User Name is Valid</li>
                  <li *ngIf="uname.invalid">User Name is Invalid</li>
                 </ul>
              </div>
              <div class="col-4">
                <ul>
                  <li *ngIf="uage.untouched">User Age is Untouched</li>
                  <li *ngIf="uage.touched">User Age is Touched</li>
                  <li *ngIf="uage.dirty">User Age is Dirty</li>
                  <li *ngIf="uage.pristine">User Age is Pristine</li>
                  <li *ngIf="uage.valid">User Age is Valid</li>
                  <li *ngIf="uage.invalid">User Age is Invalid</li>
               </ul>
              </div>
              <div class="col-4">
                <ul>
                  <li *ngIf="uphone.untouched">User Phone is Untouched</li>
                  <li *ngIf="uphone.touched">User Phone is Touched</li>
                  <li *ngIf="uphone.dirty">User Phone is Dirty</li>
                  <li *ngIf="uphone.pristine">User Phone is Pristine</li>
                  <li *ngIf="uphone.valid">User Phone is Valid</li>
                  <li *ngIf="uphone.invalid">User Phone is Invalid</li>
                 </ul>
              </div>
             </div>
            `,
  styles: [`
  input.ng-touched.ng-invalid{
    border : 5px solid crimson;
  }
  input.ng-touched.ng-valid{
    border : 5px solid darkseagreen;
  }
  `]
})
export class TemplateFormComponent {
  user = {
    name : '',
    age : '',
    phone : ''
  }
  submitHandler(form:NgForm, event:any){
    // event.preventDefault();
    // console.log("form object ",form);
    // console.log("event object ",event);
     if(form.controls['userAge'].value < 18){
        alert("you are too young to join us")
      }else if(form.controls['userAge'].value > 90){
         alert("you are too old to join us")
      }else{
         alert("welcome to the company");
         event.target.submit();
     }
  }
}
