import { Component } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  template: `
             <h2>Reactive forms</h2>
             <form [formGroup]="userForm" action="#" method="get" (submit)="submitHandler()">
               <div class="mb-3">
                <label for="userName" class="form-label">User Name : </label>
                <input formControlName="username" name="userName" class="form-control" id="userName">
                <div *ngIf="userForm.get('username')!.invalid && userForm.get('username')!.touched" class="form-text text-danger">User Name is Required</div>
              </div>
              <div class="mb-3">
                <label for="userAge" class="form-label">User Age : </label>
                <input formControlName="userage" name="userAge" class="form-control" id="userAge">
                <div *ngIf="userForm.get('userage')!.invalid && userForm.get('userage')!.touched" class="form-text text-danger">User Age is Required</div>
              </div>
              <div class="mb-3">
                <label for="userPhone" class="form-label">User Phone : </label>
                <input title="### ########" formControlName="userphone" name="userPhone" class="form-control" id="userPhone">
                <div *ngIf="userForm.get('userphone')!.invalid && userForm.get('userphone')!.touched"  class="form-text text-danger">User Phone is Required</div>
              </div>
              <button type="submit" class="btn btn-primary">Register</button>
             </form>
             <button (click)="fillName()">Fill Name</button>
             <button (click)="fillDetails()">Fill Details</button>
             <ul>
              <li> User Name : {{ userForm.get('username')!.value }}</li>
              <li> User Age : {{ userForm.get('userage')!.value }}</li>
              <li> User Phone : {{ userForm.get('userphone')!.value }}</li>
             </ul>
             <div class="row">
              <div class="col-4">
                <ul>
                  <li *ngIf="userForm.get('username')!.untouched">User Name is Untouched</li>
                  <li *ngIf="userForm.get('username')!.touched">User Name is Touched</li>
                  <li *ngIf="userForm.get('username')!.dirty">User Name is Dirty</li>
                  <li *ngIf="userForm.get('username')!.pristine">User Name is Pristine</li>
                  <li *ngIf="userForm.get('username')!.valid">User Name is Valid</li>
                  <li *ngIf="userForm.get('username')!.invalid">User Name is Invalid</li>
                 </ul>
              </div>
              <div class="col-4">
                <ul>
                  <li *ngIf="userForm.get('userage')!.untouched">User Age is Untouched</li>
                  <li *ngIf="userForm.get('userage')!.touched">User Age is Touched</li>
                  <li *ngIf="userForm.get('userage')!.dirty">User Age is Dirty</li>
                  <li *ngIf="userForm.get('userage')!.pristine">User Age is Pristine</li>
                  <li *ngIf="userForm.get('userage')!.valid">User Age is Valid</li>
                  <li *ngIf="userForm.get('userage')!.invalid">User Age is Invalid</li>
               </ul>
              </div>
              <div class="col-4">
                <ul>
                  <li *ngIf="userForm.get('userphone')!.untouched">User Phone is Untouched</li>
                  <li *ngIf="userForm.get('userphone')!.touched">User Phone is Touched</li>
                  <li *ngIf="userForm.get('userphone')!.dirty">User Phone is Dirty</li>
                  <li *ngIf="userForm.get('userphone')!.pristine">User Phone is Pristine</li>
                  <li *ngIf="userForm.get('userphone')!.valid">User Phone is Valid</li>
                  <li *ngIf="userForm.get('userphone')!.invalid">User Phone is Invalid</li>
                 </ul>
              </div>
             </div>
            `,
  styles: [`
  input.ng-touched.ng-invalid{
    border : 5px solid crimson;
  }
  input.ng-touched.ng-valid{
    border : 5px solid darkseagreen;
  }
  `]
})
export class ReactiveFormComponent {
  userForm:FormGroup;
  constructor( private fb:FormBuilder ){
    this.userForm = this.fb.group({
      username : [ '', Validators.required ],
      userage : [ '', [Validators.required, Validators.min(18), Validators.max(90)] ],
      // userphone : ['', [Validators.required, Validators.pattern('\d{3}([- ]*)\d{8}')]]
      // userphone : ['', [Validators.required, Validators.pattern('^[0-9]\d{2,4}-\d{6,8}$')]]
      // userphone : ['', [Validators.required, Validators.pattern(new RegExp("^[0-9]\d{3}-\d{8}$"))]]
      userphone : ['', [Validators.required, Validators.pattern("[0-9 ]{12}")]]
    })
  }
  ngOnInit(){
    this.userForm.get("username")?.valueChanges.subscribe(val=>console.log(val))
  }
  submitHandler(){
    // 
  }
  fillName(){
    this.userForm.patchValue({
      username : "Batman"
    })
  }
  fillDetails(){
    this.userForm.setValue({
      username : "Bruce Wayne",
      userage : 21,
      userphone : "020-12345678"
    })
  }
}

