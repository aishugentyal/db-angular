let express = require("express");
let mongoose = require("mongoose");
let cors = require("cors");
//=======================================
let config = require("./config.json");

//Modules configuration  ================
let app = express();
app.use(cors());
app.use(express.json());

let rawurl = "mongodb+srv://<admin>:<password>@<clusterName>.<clusterId>.mongodb.net/<dbname>?retryWrites=true&w=majority";
let url = rawurl.replace("<admin>",config.dbuser).replace("<password>",config.dbpass).replace("<clusterName>",config.clustername).replace("<clusterId>", config.cluseterid).replace("<dbname>", config.dbname);
//Database server configuration  ========
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Hero = mongoose.model("Hero",Schema({
    id : ObjectId,
    title: String,
    firstname: String,
    lastname: String,
    power: Number,
    city: String,
}));
console.log(url);
mongoose.connect(url).then(res=>console.log("DB Connected")).catch(err=>console.log(err))
//Route configuration  ==================
// CREATE
app.post("/data", (req, res)=>{
    let hero = new Hero(req.body)
    hero.save().then((dbres)=>{
        res.send({ message : "added", addInfo : dbres })
        console.log(dbres);
    });
})
// READ
app.get("/data", (req, res)=>{
    // Hero.find(dbRes => res.send(dbRes));
    Hero.find((error, dbRes)=> {
        if(error){
            console.log("Error ", error);
        }else{
            res.send(dbRes)
        }
    });
})

// READ BEFORE UPDATE
app.get("/edit/:heroid", (req, res)=>{
    Hero.findById({ _id: req.params.heroid }, (error, dbRes)=> {
        if(error){
            console.log("Error ", error);
        }else{
            res.send(dbRes)
        }
    });
})
// UPDATE
app.post("/edit/:heroid", (req, res)=>{
    Hero.findById({ _id: req.params.heroid }, (error, dbRes)=> {
        if(error){
            console.log("Error ", error);
        }else{
            dbRes.title = req.body.title;
            dbRes.firstname = req.body.firstname;
            dbRes.lastname = req.body.lastname;
            dbRes.power = req.body.power;
            dbRes.city = req.body.city;
            dbRes.save().then(updateRes => res.json({
                message : "updated",
                updateInfo : updateRes
            })).catch(error => console.log("Error ", error))
        }
    });
})

// DELETE
app.delete("/delete/:heroid", (req, res)=>{
    Hero.findByIdAndDelete({ _id: req.params.heroid }, (error, dbRes)=>{
        // console.log("Deleted ", dbRes.title);
        res.json({ message : "deleted", deleteInfo : dbRes})
    })
})
/* 
setTimeout(function(){
    Hero.findByIdAndDelete({ _id: "62ecba9ef692c8e02dd4da9b" }, (error, dbRes)=>{
        console.log("Deleted ", dbRes.title);
    })
},4000) 
*/
//Web server configuration  =============
app.listen(config.port, config.host, function(error){
    if(error){ console.log("Error ", error)}
    else{ console.log("Web server is now running on ",config.host,":",config.port)}
});