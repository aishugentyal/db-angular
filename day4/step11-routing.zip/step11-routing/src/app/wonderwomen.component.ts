import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';

@Component({
  selector: 'app-wonderwomen',
  template: `
    <p>
      wonderwomen works!
      Supplied Quantity : {{ qty }}
    </p>
  `,
  styles: [
  ]
})
export class WonderwomenComponent implements OnInit {
  qty = 0
  constructor( private acr : ActivatedRoute) { }

  ngOnInit(): void {
    this.qty = this.acr.snapshot.params['qty'];
  }

}
