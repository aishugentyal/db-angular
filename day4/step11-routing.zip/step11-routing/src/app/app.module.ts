import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { BatmanComponent } from './batman.component';
import { SupermanComponent } from './superman.component';
import { HomeComponent } from './home.component';
import { NotfoundComponent } from './notfound.component';
import { WonderwomenComponent } from './wonderwomen.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ AppComponent, BatmanComponent, SupermanComponent, HomeComponent, NotfoundComponent, WonderwomenComponent ],
  imports: [ BrowserModule, FormsModule, RouterModule.forRoot([
    { path:"", component : HomeComponent },/* default route */
    { path:"batman", component : BatmanComponent }, /* named route */
    { path:"superman", component : SupermanComponent },/* named route */
    { path:"wonderwomen/:qty", component : WonderwomenComponent },/* named route */
    { path:"flash", redirectTo:"batman" },/* named route */
    { path:"**", component : NotfoundComponent } /* wildcard route*/
  ]) ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
