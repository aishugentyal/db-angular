import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Routing in Angular</h1>
    <input [(ngModel)]="quantity" type="range">Quantity : {{ quantity }}
    <ul>
      <li><a [routerLink]="['']"  routerLinkActive="player" [routerLinkActiveOptions]="{ exact : true }">Home</a></li>
      <li><a [routerLink]="['batman']"  routerLinkActive="player">Batman</a></li>
      <li><a [routerLink]="['superman']"  routerLinkActive="player">Superman</a></li>
      <li><a [routerLink]="['wonderwomen',quantity]"  routerLinkActive="player">Wonder Women</a></li>
      <li><a [routerLink]="['flash']"  routerLinkActive="player">Flash</a></li>
      <li><a [routerLink]="['cyborg']"  routerLinkActive="player">Cyborg</a></li>
      <li><a [routerLink]="['aquaman']"  routerLinkActive="player">Aquaman</a></li>
    </ul>
    <router-outlet></router-outlet>
  `,
  styles: [`
    .player{
      background-color : crimson;
      color : papayawhip;
    }
  `]
})
export class AppComponent {
  title = 'step11-routing';
  quantity = 0;
}
