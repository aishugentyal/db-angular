import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   
  `,
  styles: []
})
export class AppComponent {
  title = 'step13-testing';
  heroname = "Batman";
  heropower = 5
}
