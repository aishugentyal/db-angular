import { AppComponent  } from "./app.component";

describe("checking hero name", ()=>{
    let app:any = null;
    beforeEach(()=>{
        app = new AppComponent();
    });
    it("should check for heroname to be defined",()=>{
        expect(app.heroname).toBeDefined()
    })
    it("should be Batman",()=>{
        expect(app.heroname).toBe("Batman")
    })
    it("should check power to be defined",()=>{
        expect(app.heropower).not.toBeUndefined()
    })
    it("should check power to be 5",()=>{
        expect(app.heropower).toBe(5)
    })
    afterEach(()=>{
        app = null;
    });
})