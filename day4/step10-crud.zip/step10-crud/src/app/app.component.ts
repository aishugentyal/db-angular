import { Component } from '@angular/core';

import { HeroCRUDServices } from './herocrud.service';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1>Angular Crud Application</h1>
      
      <div *ngIf="show">
        <h2>Add New Hero</h2>
        <div class="mb-3">
          <label for="herotitle" class="form-label">Hero Title</label>
          <input
            [(ngModel)]="nhero.title"
            class="form-control"
            id="herotitle"
          />
        </div>
        <div class="mb-3">
          <label for="herofirstname" class="form-label">Hero First Name</label>
          <input
            [(ngModel)]="nhero.firstname"
            class="form-control"
            id="herofirstname"
          />
        </div>
        <div class="mb-3">
          <label for="herolastname" class="form-label">Hero Last Name</label>
          <input
            [(ngModel)]="nhero.lastname"
            class="form-control"
            id="herolastname"
          />
        </div>
        <div class="mb-3">
          <label for="herpower" class="form-label">Hero Power</label>
          <input
            [(ngModel)]="nhero.power"
            type="range"
            min="0"
            max="10"
            step="1"
            class="form-control"
            id="herpower"
          />
        </div>
        <div class="mb-3">
          <label for="herocity" class="form-label">Hero City</label>
          <input [(ngModel)]="nhero.city" class="form-control" id="herocity" />
        </div>
        <button (click)="clickHandler()" type="submit" class="btn btn-primary">
          Add Hero
        </button>
        <div>
        </div>
      </div>

      <div *ngIf="!show">
          <h2>Edit Selected Hero's Info</h2>
          <div class="mb-3">
            <label for="e_herotitle" class="form-label">Edit Hero Title</label>
            <input
              [(ngModel)]="ehero.title"
              class="form-control"
              id="e_herotitle"
            />
          </div>
          <div class="mb-3">
            <label for="e_herofirstname" class="form-label"
              >Edit Hero First Name</label
            >
            <input
              [(ngModel)]="ehero.firstname"
              class="form-control"
              id="e_herofirstname"
            />
          </div>
          <div class="mb-3">
            <label for="e_herolastname" class="form-label" >Edit Hero Last Name</label >
            <input
              [(ngModel)]="ehero.lastname"
              class="form-control"
              id="e_herolastname"
            />
          </div>
          <div class="mb-3">
            <label for="e_herpower" class="form-label">Edit Hero Power</label>
            <input
              [(ngModel)]="ehero.power"
              type="range"
              min="0"
              max="10"
              step="1"
              class="form-control"
              id="e_herpower"
            />
          </div>
          <div class="mb-3">
            <label for="e_herocity" class="form-label">Edit Hero City</label>
            <input
              [(ngModel)]="ehero.city"
              class="form-control"
              id="e_herocity"
            />
          </div>
          <button (click)="updateHandler()" type="submit" class="btn btn-primary" >  Update Hero Info </button>
          <div>
       </div>
      </div>
          <!-- edit form ends -->
      
      <hr />
      <table class="table">
            <thead>
              <tr>
                <th scope="col">Sl #</th>
                <th scope="col">Title</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Power</th>
                <th scope="col">City</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let hero of heroeslist; index as idx">
                <td>{{ idx + 1 }}</td>
                <td>{{ hero.title }}</td>
                <td>{{ hero.firstname }}</td>
                <td>{{ hero.lastname }}</td>
                <td>{{ hero.power }}</td>
                <td>{{ hero.city }}</td>
                <td>
                  <button (click)="editHero(hero._id)" class="btn btn-warning">Edit</button>
                </td>
                <td>
                  <button (click)="deleteHero(hero._id)" class="btn btn-danger">Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
    </div>
  `,
  styles: [],
})
export class AppComponent {
  title = 'step10-crud';
  heroeslist: any = [];
  show = true;
  nhero: any = {
    title: '',
    firstname: '',
    lastname: '',
    power: 0,
    city: '',
  };
  ehero: any = {
    id: '',
    title: '',
    firstname: '',
    lastname: '',
    power: 0,
    city: '',
  };
  constructor(private hs: HeroCRUDServices) {}
  refresh() {
    this.hs.getData().subscribe((res) => (this.heroeslist = res));
  }

  ngOnInit() {
    this.refresh();
  }

  clickHandler() {
    this.hs.addData(this.nhero).subscribe((res) => {
      console.log(res);
      this.refresh();
      this.nhero = {
        title: '',
        firstname: '',
        lastname: '',
        power: 0,
        city: '',
      };
    });
  }

  editHero(editHero: any) {
    // alert("you clicked the edit button "+ editHero);
    this.hs.readToUpdate(editHero).subscribe((res) =>{
      this.ehero = res;
      this.show = false;
    });
  }
  deleteHero(heroid: any) {
    // alert("you clicked the delete button "+heroid)
    this.hs.deleteHero(heroid).subscribe((res) => {
      this.refresh();
    });
  }
  updateHandler() {
    this.hs.updateInfo(this.ehero).subscribe((res) => {
      this.refresh();
      this.show = true;
    });
  }
}
