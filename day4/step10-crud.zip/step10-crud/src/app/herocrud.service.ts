import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class HeroCRUDServices {
    url = "http://localhost:5050"
    constructor(private http:HttpClient){}
    getData(){
        return this.http.get(this.url+"/data");
    }
    addData(nhero:any){
        return this.http.post(this.url+"/data", nhero);
    }
    readToUpdate(heroId:any){
        return this.http.get(this.url+"/edit/"+heroId);
    }
    updateInfo(uhero:any){
        return this.http.post(this.url+"/edit/"+uhero.id,uhero);
    }
    deleteHero(heroId:any){
        return this.http.delete(this.url+"/delete/"+heroId);
    }
}